<?php


class PaymentUserController extends BaseController {


}