



<div class="large-2 small-12 columns " style="width: 15.66667%;">
	<div class="sidebar " style=" margin-left: -3rem; margin-right: 1rem; ">
		<ul class="side-nav">
			<br><br><br><br>
			<li>{{ link_to('/mainpage', 'Home', array("class"=>"button login-btn small radius right size-14", "title"=>"Check all the Device that is being used.", "style"=>" margin-left: 3rem; ")) }}</li>
		</ul>
	</div>
</div>