



<div class="large-2 small-12 columns push-1" style=" border-right-style: solid; border-right-width: 2px; border-right-color: #DDD; margin-top: 2rem !important;">
	<div class="sidebar " style=" margin-right: 1rem; ">
		<ul class="side-nav">
			<li>{{ link_to('add/user', " Create User", ["class"=>"lrv-link tiny size-14", "style"=>" margin-left: 3rem; "]) }}</li>
			<li>{{ link_to('add/user', " Create User", ["class"=>"lrv-link tiny size-14", "style"=>" margin-left: 3rem; "]) }}</li>
		</ul>
	</div>
</div>