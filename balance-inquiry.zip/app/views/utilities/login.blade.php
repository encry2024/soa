<div class=" sticky fixed ">
	<nav class="top-bar" data-topbar role="navigation">
		<ul class="title-area">
			<li class="name">
			<h1><a href="#">STI - Authenticate Login</a></h1>
			</li>
		</ul>
	</nav>
</div>
