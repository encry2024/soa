



<div class="large-2 small-12 columns" style=" border-right-style: solid; border-right-width: 2px; border-right-color: #DDD; margin-top: 2rem !important;">
	<div class="sidebar ">
		<ul class="side-nav">
			@if (Auth::user()->type != 'student')
				<li></li>
				<li>{{ link_to('print/student/'.$user->username.'/soa', 'Print SOA', ['class'=>'button login-btn large-10 tiny radius right size-14', "style"=>" margin-right: 1rem; "]) }}</li>
				<li>{{ link_to('#', 'Payment Breakdown', ['class'=>'button login-btn tiny large-10 radius right size-14', 'data-reveal-id' => 'payment_breakdown', "style"=>" margin-right: 1rem; "]) }}</li>
			@else
				<li>{{ link_to('#', 'Payment Breakdown', ['class'=>'button login-btn tiny radius right size-14', 'data-reveal-id' => 'payment_breakdown']) }}</li>
			@endif
			<br><br>
		</ul>
	</div>
</div>