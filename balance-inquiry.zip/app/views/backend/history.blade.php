



<div class="large-10 columns large-centered">
<br>
	<label class="size-24 nsi-asset-fnt label-black left" style="margin-left: -3rem;">HISTORY</label>
	<br><br>
	<table id="history" class="dtable large-12" style="width: 100%; margin-bottom: 1rem;">
	</table>
</div>