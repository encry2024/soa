<h1>Hi, {{ $username }} </h1>
<br><br>
<p>Your new password is {{ $password }}</p>
<br><br><br>
<label>STI COLLEGE MUÑOZ-EDSA</label>
<br>
Tanco-cu Bldg., EDSA, Quezon City <br>
920-8645 / 927-3967 / 3970 / 3979
<br> <br> <br>