@extends('Template.Template')

@section('head')
@endsection

@section('body')

	<!-- REGISTRATION FIELD -->
	@include('field.register')
	<!--  -->
@endsection