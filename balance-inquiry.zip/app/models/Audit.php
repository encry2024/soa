<?php

class Audit extends Eloquent {
	
}